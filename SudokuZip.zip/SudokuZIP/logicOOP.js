document.addEventListener("DOMContentLoaded",
    function(event) {


        function Grid(){

            this.loadedSudoku;
            this.inputs = document.getElementsByClassName("puzNum");
            this.code = null;
            this.codeNoDiff = null;
            this.difficulty = 0;
            this.stack = [];
            this.hintUsed = false;

            this.codeConverter = function(num, direction) {
                var alpha = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
                if (direction == "toCode") {
                    return (alpha[Math.floor(num / 26)] + alpha[num % 26]).toUpperCase();
                } else if (direction == "toInt") {
                    return 26 * alpha.indexOf(num[0].toLowerCase()) + alpha.indexOf(num[1].toLowerCase());
                } else {
                    console.log("Code conversion error!");
                }
            }

	    this.getPuzzle = async function(num) {
		var socket = io.connect('http://localhost:3000');
		socket.emit('puzRequest',{puzNum: num});
		var temp = 0;
		socket.on('puzzle', function(data){
		    //console.log("data: "+data.puzString);
		    temp = data.puzString;
		});
		await new Promise((resolve,reject) => setTimeout(resolve,500));
		console.log("puzzling");	
		return temp;
	    };


            this.generate = async function() {
                document.querySelector("#hint").disabled=false;
                document.querySelector("#hint").style.backgroundColor="#FFC300";
                var loadedSudoku = this.loadedSudoku;
                var inputs = this.inputs;
                pi = 3.1415926535897932384626433832795028841971693993751; //Decimal
                code = this.code;
                codeNoDiff = this.codeNoDiff;
                difficulty = this.difficulty;
                stack = this.stack;
                // hintUsed = this.hintUsed;

                //Regular expression to check code is of correct type (LetterLetterDigit)
                var letter1 = '([a-z])';
                var letter2 = '([a-z])';
                var digit = '[0-3]'; //digit 0-3
                var codeExp = new RegExp(letter1 + letter2 + digit, ["i"]); //case insensitive

                //Uses the inputted CODE; if empty generates random code for sudoku from database
                if (document.getElementById("code").value.length != 0 && codeExp.test(document.getElementById("code").value)) {
                    code = document.getElementById("code").value;
                    codeNoDiff = code[0] + code[1];
                    difficulty = code[2];
                    console.log(codeNoDiff);
                } else {
                    codeNoDiff = this.codeConverter(Math.floor(Math.random() * 675), "toCode");
                }

                //While database not working, set LOADEDSUDOKU to one from the plainSudokus array
                //loadedSudoku = await this.getPuzzle(this.codeConverter(codeNoDiff,"toInt"));
		loadedSudoku = puzzleArray[this.codeConverter(codeNoDiff,"toInt")];
		
                //Fills the grid with LOADEDSUDOKU
                for (var i = 0; i < 81; i++) {
                    inputs[i].placeholder = loadedSudoku[i];
                    inputs[i].value = "";
                    inputs[i].style.backgroundColor = "white";
                    inputs[i].disabled = true;
                };

                //If no CODE inputted, changes difficulty depending on radio input or default
                if (document.getElementById("code").value.length == 0 && document.querySelector('input[name="difficulty"]:checked') != null) {
                    difficulty = document.querySelector('input[name="difficulty"]:checked').value;
                } else if (document.getElementById("code").value.length == 0) {
                    difficulty = 1;
                }

                //Editting Board Title to match settings
                var diffNames = ["Easy", "Medium", "Hard", "Master"];
                document.getElementById("title").textContent = "Sudoku"+" "+(codeNoDiff + difficulty)+" "+diffNames[difficulty];
                code = codeNoDiff + difficulty;

                //Empties a puzNum text input box for user interaction
                function enableCell(row, col) {
                    inputs[row * 9 + col].placeholder = "";
                    inputs[row * 9 + col].disabled = false;
                }

                //Pseudorandom base 9 integer using Pi            
                function genRand(num) {
                    return Math.trunc(pi * num % 9);
                }

                //Creating empty spaces depending on difficulty and total number of candidates
                var diffValues = [30, 36, 40, 50];
                var candidates = 0;
                var emptyDiff = parseInt(difficulty) + 1;
                var temp = 0;
                var array2D = new Array(9);
                for (var i = 0; i < 9; i++) {
                    array2D[i] = new Array(9);
                    for (var j = 0; j < 9; j++) {
                        array2D[i][j] = parseInt(loadedSudoku[i * 9 + j]);
                    }
                };

                var seed = this.codeConverter(codeNoDiff, "toInt");

                //EMPTY CELL COUNTING FUNCTION
                function emptyCounter() {
                    var count = 0;
                    for (var i = 0; i < 81; i++) {
                        if (inputs[i].disabled == false) {
                            count++;
                        }
                    }
                    return count;
                }

                // Empties random from every row, column and box
                function diffChecker(){return emptyCounter()<diffValues[difficulty]};

                while(diffChecker()){
                    for (var i = 0; i < 9; i++) {
                        if (diffChecker() && inputs[i * i, genRand(seed)].disabled == true) {
                            enableCell(i, genRand(seed));
                        };
                        seed += 2;
                        if (diffChecker() && inputs[genRand(seed)*9+i].disabled == true) {
                            enableCell(genRand(seed), i);                    
                        };
                        seed += 3;
                        var boxRow = Math.floor(genRand(seed) / 3) + i - i % 3;
                        var boxCol = genRand(seed) % 3 + (i % 3) * 3;
                        if (inputs[boxRow*9+boxCol].disabled == true) {
                            enableCell(Math.floor(genRand(seed) / 3) + i - i % 3, genRand(seed) % 3 + (i % 3) * 3);
                        };
                    }
                };

                this.loadedSudoku = loadedSudoku
                this.inputs = inputs;
                this.code = code;
                this.codeNoDiff = codeNoDiff;
                this.difficulty = difficulty;
                this.stack = stack;
                // this.hintUsed = hintUsed;


            };

        };

        function undoAction(Grid){
            if(Grid.stack.length>0){
                var undoData = stack.pop();
                Grid.inputs[undoData[0]].value = undoData[1];
                Grid.inputs[undoData[0]].oldVal = Grid.inputs[undoData[0]].value;
            }
        }

        //Gives the player a hint
        function hinter(Grid){
            if(!Grid.hintUsed){
                Grid.hintUsed = true;
                var cellCoord = Math.trunc(Math.random()*81);
                while(Grid.inputs[cellCoord].disabled==true){
                    cellCoord = Math.trunc(Math.random()*81);
                }
                document.querySelector("#hint").disabled=true;
                Grid.inputs[cellCoord].placeholder = Grid.loadedSudoku[cellCoord];
                Grid.inputs[cellCoord].disabled = true;
                Grid.inputs[cellCoord].style.backgroundColor="#AAFF00";
                setTimeout(function(){ Grid.inputs[cellCoord].style.backgroundColor="white"; }, 1500);
                document.querySelector("#hint").style.backgroundColor="#FF5733";
            };
        }

        function share(Grid){
            const copiedCode = document.createElement('textarea');
            copiedCode.value = Grid.code;
            document.body.appendChild(copiedCode);
            copiedCode.select();
            document.execCommand('copy');
            document.body.removeChild(copiedCode);
            alert("Your sudoku code ("+Grid.code+") has been copied to the clipboard!");    
        }

        // printing:
        // https://stackoverflow.com/questions/12997123/print-specific-part-of-webpage
        //BEST: https://www.arclab.com/en/kb/htmlcss/how-to-print-a-specific-part-of-a-html-page-css-media-screen-print.html

        // Checks for contradictions between LOADEDSUDOKU and the UI game board
        function checkSudoku(Grid) {
            var correct = true;
            for (var i = 0; i < 81; i++) {
                if (Grid.inputs[i].disabled == true || Grid.inputs[i].value === Grid.loadedSudoku[i] || Grid.inputs[i].value == "") {
                    Grid.inputs[i].style.backgroundColor = "white";
                    if (!(Grid.inputs[i].disabled == true || Grid.inputs[i].value === Grid.loadedSudoku[i])){
                        correct = false;
                    }
                } else {
                    Grid.inputs[i].style.backgroundColor = "#FF5733";
                    correct = false;
                }
            }
            if(correct){
                alert("All correct! Share with your friends by pressing Share.")
            }
        };

        var test = new Grid();
        test.generate();
        console.log("hi")
        for (var x = 0; x < 81; x++) {
            test.inputs[x].coord = x;
            test.inputs[x].oldVal = "";
            test.inputs[x].onchange = function() {
                temp = [this.coord, this.oldVal];
                test.stack.push(temp);
                this.oldVal = this.value;
                if (document.getElementById("autoCheck").checked == true) {
                    checkSudoku(test);
                };
            };
        }

        document.querySelector("#generate")
            .addEventListener("click", function(){
                test = new Grid();
                test.generate();
            });

        document.querySelector("#checkButton")
            .addEventListener("click", function(){checkSudoku(test)});

        document.querySelector("#undo")
            .addEventListener("click", function(){undoAction(test)});

        document.querySelector("#hint")
            .addEventListener("click", function(){hinter(test)}); 

        document.querySelector("#share")
            .addEventListener("click", function(){share(test)}); 


    }
);
