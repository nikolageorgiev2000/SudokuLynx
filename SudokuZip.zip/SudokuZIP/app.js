var express = require('express');
var app = express();
var server = app.listen(3000, function(){console.log("Live at Port 3000");});
var io = require('socket.io').listen(server);
var router = express.Router();
var path = __dirname + '/';
var sqlite3 = require('sqlite3').verbose();
var db = new sqlite3.Database('sudokuLynx.db');

//var fs = require('fs');
//var contents = fs.readFileSync('/home/pi/Desktop/Sudoku/PlainSudokus.txt','utf-8');

//,function(err, contents) {
    //console.log(contents);
    //var puzzles = contents.trim().split(".");
    //var counter = 0;
    //var i = 0;
    //while(i<676){
    //    db.run('insert into puzzles (puzString) values (\''+puzzles[i]+'\');');
    //    i++;
    //};
    //console.log("count"+counter);
//});

//var name = "john";
//var email = "n@n.g";
//var diff = 10;

//CREATE TABLE subs( id integer PRIMARY KEY, name text NOT NULL, email text NOT NULL UNIQUE, difficulty integer NOT NULL UNIQUE);


router.use(function (req,res,next) {
  console.log("/" + req.method);
  next();
});

app.get('/styles.css', function(req, res) {
  res.sendFile(path  + "styles.css");
});

app.get('/LOGO.png', function(req, res) {
  res.sendFile(path  + "LOGO.png");
});

app.get('/logicOOP.js', function(req, res) {
  res.sendFile(path + "logicOOP.js");
});

app.get('/subscribe.js', function(req, res) {
  res.sendFile(path + "subscribe.js");
});

app.get('/daily.js', function(req, res) {
  res.sendFile(path + "daily.js");
});

app.get('/socket.io/socket.io.js', function(req, res) {
  res.sendFile("/home/pi/Desktop/Sudoku/node_modules/socket.io-client/dist/socket.io.js");
});;

// define interactions with client
io.on('connection', function(socket){
    //console.log("connected");
    //recieve client data
    socket.on('subbed', function(data){
	console.log(data);
        db.run('insert into subs (name, email, difficulty) values (\''+data.name+'\',\''+data.email+'\',\''+data.diff+'\');');
	//db.run('insert into subs (name, email, difficulty) values (\''+"name"+'\',\''+"email"+'\',\''+"diff"+'\');');
    });
    socket.on('puzRequest', function(data){
	var puzNum = data.puzNum + 1;
	console.log(puzNum);
	var puzString;
	db.all(('select puzString from puzzles where id='+puzNum), function(err, rows) {
            	rows.forEach(function (row) {
			console.log("puzString: "+row.puzString);
			socket.emit('puzzle',{puzString: row.puzString});
		});
        });
    });
});

app.get('/logicOOP.js', function(req, res) {
  res.sendFile(path + "logicOOP.js");
});

app.get('/plainSudokus.js', function(req, res) {
  res.sendFile(path + "plainSudokus.js");
}); 

router.get("/",function(req,res){
  res.sendFile(path + "index.html");
});

router.get("/challenge",function(req,res){
  res.sendFile(path + "challenge.html");
});

router.get("/subscribe",function(req,res){
  //console.log("sub!");
  res.sendFile(path + "subscribe.html");
});

app.use("/",router);

app.use("*",function(req,res){
  res.sendFile(path + "index.html");
});

