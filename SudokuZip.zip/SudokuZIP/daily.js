document.addEventListener("DOMContentLoaded",
    function(event) {

    	//Set Daily Sudoku Challenge
    	document.getElementById("code").value = "HC1";

    }
);